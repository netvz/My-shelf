package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.fxml.FXML;
import java.awt.*;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import javafx.scene.image.ImageView;

import static java.lang.Integer.valueOf;
import static sample.Menu.addingPage;


public  class AddingPage  implements Initializable {


    @FXML
    public TextField nameText, brandText;
    @FXML
    private Button savebutton, backbutton2;
    @FXML
    private ChoiceBox<String> choiceBox1;
    @FXML
    private ComboBox<Integer> mmchoice, rrrchoice, ddchoice; // uzywasz combobox zamiast choice box poniewaz w combobox mozna ustawic poczatkowa wartosc tak zwany Prompttext
    @FXML
    public Label typelabel, brandlabel, namelebe;
    @FXML
    private ImageView myImageView;

    private Desktop desktop = Desktop.getDesktop();
    final FileChooser fileChooser = new FileChooser(); // tworzysz file choosera ktorego potem uzywasz do otwierania zdjecia
   // Tutaj tworzysz arrays ktore potem uzywasz aby wyswietlic je jako opcje w choicebox i combobox
    //uzycie valueof pozwala przedstawic array z integers
    private String[] type = {"Cleanser", "Exfoliator", "Serum", "Face Oil", "Sunscreen","Moisturizer","Chemical Peel", "Toner","Face Mask"};
    private Integer[] mm = {valueOf("1"), valueOf("2"), valueOf("3"),valueOf("4"),valueOf("5"),valueOf("6"),valueOf("7"),valueOf("8"),valueOf("9"),valueOf("10"),valueOf("11"),valueOf("12")};
    private Integer[] dd = {valueOf("1"), valueOf("2"), valueOf("3"),valueOf("4"),valueOf("5"),valueOf("6"),valueOf("7"),valueOf("8"),valueOf("9"),valueOf("10"),valueOf("11"),valueOf("12"),valueOf("13"), valueOf("14"), valueOf("15"),valueOf("16"),valueOf("17"),valueOf("18"),valueOf("19"),valueOf("20"),valueOf("21"),valueOf("22"),valueOf("23"),valueOf("24"),valueOf("25"),valueOf("26"),valueOf("27"),valueOf("28"),valueOf("29"),valueOf("30"),valueOf("31")};
    private Integer[] rrr = {valueOf("2020"), valueOf("2021")};

    private Window stage;

    public void gotomenu() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Sample.fxml"));
        Parent root = fxmlLoader.load();
        addingPage.close();
    }
    // Tutaj metodzie hadnle save przypisujesz co ma robic
    public void handlesave(ActionEvent actionEvent) {
        // Tutaj w terminalu wyswietla to co sie napisalo w text file
        System.out.println(nameText.getText());
        System.out.println(brandText.getText());
        String filename = nameText.getText();


        try {

            FileWriter productfile = new FileWriter(nameText.getText() + ".txt"); // Tutaj tworzy plik z nazmwa pobrana oduzytkownika i potem uzywasz metody (.write) ktora wpisuje do file te rzeczy ktore wprowdzil uzytkownik albo wybral
            productfile.write("Name: " + nameText.getText() + "\n"); // Tutaj jest napisane to co bedzie wyswietlalo sie w file
            productfile.write("Brand: " + brandText.getText() + "\n");// Tutaj jest napisane to co bedzie wyswietlalo sie w file
            productfile.write("Type: " + choiceBox1.getValue() + "\n");// Tutaj jest napisane to co bedzie wyswietlalo sie w file
            productfile.write("Exp. date: " + mmchoice.getValue() + " " + ddchoice.getValue() + " " + rrrchoice.getValue());// Tutaj jest napisane to co bedzie wyswietlalo sie w file
            productfile.flush();
            productfile.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Success..."); // To wyswietla sie w termianlu jezeli plik sie tworzyl i wszystko sie zapisalo, uzywa sie tego przy testowaniu zbey nie musiec wchodzic w ten plik
    }




// .getItems().addAll dodaje wszystkie elementy z array do choicebox i combobox
    //.setOnAction przypisuje  metode ktore sa potem zdefiniowane tym choicebox i combobox
        @Override
        public void initialize (URL url, ResourceBundle resourceBundle){
            choiceBox1.getItems().addAll(type);
            choiceBox1.setOnAction(this::getType);
            mmchoice.getItems().addAll(mm);
            mmchoice.setOnAction(this::getMm);
            ddchoice.getItems().addAll(dd);
            ddchoice.setOnAction(this::getDd);
            rrrchoice.getItems().addAll(rrr);
            rrrchoice.setOnAction(this::getRrr);


        }
// Teraz nastene 4 metody uzywam bardziej do testowania zeby w terminalu pokazywaly mi sie wybory z choicebox i combobox  dzieki czemu widze bez zamykania programu czy dziala poprawie wybieranie options
        private void getType (ActionEvent actionEvent){
            String producttype = choiceBox1.getValue();
            System.out.println(producttype);
        }
        private void getMm (ActionEvent actionEvent){
            Integer mounth = mmchoice.getValue();
            System.out.println(mounth);

        }
        private void getDd (ActionEvent actionEvent){
            Integer day = ddchoice.getValue();
            System.out.println(day);
        }
        private void getRrr (ActionEvent actionEvent){
            Integer year = rrrchoice.getValue();
            System.out.println(year);

        }

    }
